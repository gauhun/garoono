#!/bin/zsh
# Renders every shot_*.html as iPhone 6.3" (1206x2622) and iPad 13" (2064x2752) PNGs in out/
set -e
cd "$(dirname "$0")"
CHROME="/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
mkdir -p out/iphone out/ipad
for page in shot_*.html; do
  for device in iphone ipad; do
    [[ $device == iphone ]] && size=1206,2622 || size=2064,2752
    png="out/$device/${page%.html}.png"
    "$CHROME" --headless=new --disable-gpu --hide-scrollbars --force-device-scale-factor=1 \
      --window-size=$size --allow-file-access-from-files --virtual-time-budget=3000 \
      --screenshot="$PWD/$png" "file://$PWD/$page#$device" >/dev/null 2>&1
    echo "$(sips -g pixelWidth -g pixelHeight $png | tail -2 | awk '{printf "%s ", $2}') $png"
  done
done
